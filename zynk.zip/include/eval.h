#ifndef SHELL_EVAL_H
#define SHELL_EVAL_H

#include "mbtype.h"
#include "common.h"
#include "parser.h"
#include "lexer.h"
#include <string.h>

struct EvalCtx;

#define ZYNK_MAGIC_CLASS     0x434C4153
#define ZYNK_MAGIC_INSTANCE  0x494E5354
#define ZYNK_MAGIC_ARRAY     0x434C4152



typedef enum {
	VAL_NONE = 0,
	VAL_NUMBER = 1,
	VAL_STRING = 2,
	VAL_FUNC = 3,
	VAL_CFUNC = 4,
	VAL_DICT = 5, // las clases seran diccionarios JAJAJJAJAJAJJA
	VAL_ARRAY = 6,
	VAL_OBJ = 7, // objeto no estandar
	VAL_UINT = 8,
} ValType;

struct ZFunc;
struct ShellValue;
struct Object;
struct CFunc;
struct Func;

typedef struct {
	uint32_t refc;
	uint32_t magic;
} Obj;

typedef struct GCObj {
	struct GCObj *last; // el anterior
	struct GCObj *next;
	Obj obj;
} GCObj;

struct CFunc;
struct ArrayObj;
struct Array;



typedef struct Object {
	int capacity;
	uint8_t info[];
} Object;

typedef struct {
	GCObj data;
	int capacity;
	uint8_t info[];
} RealObj;

typedef struct ShellValue {
	ValType type;
	union {
		size_t uint; // hehehehhe
		double num;
		char *str;
		void *comodin;
		void  *c_func; // now is like comodin
		struct ZFunc *func;
		struct Object *obj;
		struct Array *arr;
	} as;
	//uint32_t refc; // no se
} ShellValue;

typedef ShellValue (*NativeFunc)(int argc, ShellValue *args);

typedef NativeFunc CFunc;





typedef struct ArrayObj {
    GCObj data;
    int size;
    int capacity;
    ShellValue *items; // Un array plano de valores de Zynk
} ArrayObj;

typedef struct Array {
	int size;
	int capacity;
	ShellValue *items;
} Array;



typedef struct {
	Obj data;
	char str[];
} String;

typedef struct {
	Obj data;
	struct EvalCtx *ctx;
} Namespace;

typedef struct ZFunc {
	struct EvalCtx *ctx;
	ASTNode *program;
} ZFunc;

typedef struct {
	GCObj data;
	struct EvalCtx *ctx;
	ASTNode *program;
} ZFuncObj;

typedef struct {
	char *name;
	ShellValue val;
	bool is_set;
} Var;

struct EvalCtx;

typedef struct {
	GCObj data;
	struct EvalCtx *ctx;
	ASTNode *program;
} ClassObj;

typedef struct {
	GCObj data;
	struct EvalCtx *ctx;
} InstanceObj;


typedef struct {
    Obj data;
    size_t ip;         
    struct EvalCtx *closure_ctx; 
} ZFuncVMObj;


ShellValue newVMFuncVal(size_t ip, struct EvalCtx *closure_ctx);
ShellValue newClassVal(struct EvalCtx *ctx, ASTNode *program);
ShellValue newInstanceVal(struct EvalCtx *ctx);


typedef struct EvalCtx {
	struct EvalCtx *parent;
	struct EvalCtx *global;
	size_t arg_used;
	Var *var_table;
	Var *argv;
	size_t argc;
	size_t var_cap;
	
	int (*command_handler)(ASTNode *command, struct EvalCtx *ctx);

	int last_exit_code;

	bool should_break;
	bool should_ret;
	ShellValue ret;
	bool should_exit;
	
	int exit_code;
} EvalCtx;

void growArray(Array *array);
ShellValue newObjVal(int size);
ShellValue newArrayVal();
ShellValue newNumVal(double num);
ShellValue newStrVal(const char *str);
void freeVal(ShellValue val);
void addShellArg(EvalCtx *ctx, ShellValue val);
ShellValue getShellArg(EvalCtx *ctx, size_t id);

void unlinkObj(GCObj *obj);
void addObj(GCObj *obj);
void delObj(GCObj *obj);
void zynk_gc();
void zynk_clean();

/*
 * Status Codes
 * 
 * - 0 Ok
 * - 1 Err
 * - 2 Break Statement
 * - 3 Return Statement
 * - 4 Exit Statement (not implemented yet)
 *
 */

EvalCtx *get_global();
void set_global(EvalCtx *ctx);
EvalCtx *newShellCtx();
void midKillShellCtx(EvalCtx *ctx);
void killShellCtx(EvalCtx *ctx);
Var *getShellVarEntry(EvalCtx *ctx, char *name);
Var *getShellVarEntrySilent(EvalCtx *ctx, char *name);
void setShellVarEntry(EvalCtx *ctx, char *name, ShellValue val);
void defShellVarEntry(EvalCtx *ctx, char *name, ShellValue val);
void delShellVarEntry(EvalCtx *ctx, char *name);
uint32_t zhash(char *name); // aham, a futuro


void printVal(ShellValue val);
ShellValue ref_add(ShellValue val);
void ref_del(ShellValue val);
void sref_del(void *ptr);
void *sref_add(void *ptr);
ShellValue evalExpr(ASTNode *expr, EvalCtx *ctx);
int eval(ASTNode *ast, EvalCtx *ctx);
bool isTruly(ShellValue val);

#endif
