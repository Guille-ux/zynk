#include "../include/globals.h"
#include "../include/eval.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include "../include/lexer.h"
#include "../include/parser.h"
#include <stdlib.h>
#include <dirent.h>
#include <math.h>

ShellValue native_array_constructor(int argc, ShellValue *args);

typedef enum {
    PTR_RAW,       // kfree plano (para strings sueltos o buffers)
    PTR_AST,       // parser_free_ast para el árbol
    PTR_TOKENS     // no se
} PtrType;

typedef struct {
    void *ptr;
    PtrType type;
} TrackedItem;

typedef struct {
    TrackedItem *items;
    size_t count;
    size_t capacity;
} MemTracker;

MemTracker *active_tracker = NULL;

void init_tracker() {
    active_tracker = kmalloc(sizeof(MemTracker));
    active_tracker->count = 0;
    active_tracker->capacity = 64;
    active_tracker->items = kmalloc(sizeof(TrackedItem) * active_tracker->capacity);
}

void track_pointer(void *ptr, PtrType type) {
    if (active_tracker == NULL || ptr == NULL) return;
    
    if (active_tracker->count >= active_tracker->capacity) {
        active_tracker->capacity *= 2;
        TrackedItem *new_items = kmalloc(sizeof(TrackedItem) * active_tracker->capacity);
        memcpy(new_items, active_tracker->items, sizeof(TrackedItem) * active_tracker->count);
        kfree(active_tracker->items);
        active_tracker->items = new_items;
    }
    
    active_tracker->items[active_tracker->count++] = (TrackedItem){.ptr = ptr, .type = type};
}

void free_tracked_memory() {
    if (active_tracker == NULL) return;
    
    for (size_t i = 0; i < active_tracker->count; i++) {
        TrackedItem item = active_tracker->items[i];
        if (item.ptr != NULL) {
            if (item.type == PTR_AST) {
                parser_free_ast((ASTNode*)item.ptr);
            } else if (item.type == PTR_TOKENS) {
                lexer_free((Token*)item.ptr); 
            } else {
                kfree(item.ptr);
            }
        }
    }
    
    kfree(active_tracker->items);
    kfree(active_tracker);
    active_tracker = NULL;
}

#ifdef _WIN32
    #include <direct.h>
    #include <windows.h>
    #define chdir _chdir
#else
    #include <unistd.h>
#endif

ShellValue native_sqrt(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newNumVal(sqrt(args[0].as.num));
}
ShellValue native_pow(int argc, ShellValue *args) {
	if (argc < 2) return newNumVal(-1);
	return newNumVal(pow(args[0].as.num, args[1].as.num));
}
ShellValue native_abs(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newNumVal(fabs(args[0].as.num));
}
ShellValue native_ln(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newNumVal(log(args[0].as.num));
}

ShellValue native_exists(int argc, ShellValue *args) {
	if (argc < 2) return newNumVal(-1);
	InstanceObj *inst = (InstanceObj*)((size_t)args[1].as.comodin - sizeof(GCObj));
	EvalCtx *inst_ctx = inst->ctx;
	EvalCtx *parent = inst_ctx->parent;
	inst_ctx->global = NULL;
	inst_ctx->parent = NULL;
	Var *v = getShellVarEntrySilent(inst_ctx, args[0].as.str);
	inst_ctx->parent = parent;
	inst_ctx->global = get_global();
	if (v==NULL) return newNumVal(0);

	return newNumVal(1);
}

ShellValue native_sleep(int argc, ShellValue *args) {
	if (argc < 1 || args[0].type != VAL_NUMBER) {
	return newNumVal(0);
	}

	double ms = args[0].as.num; 

#ifdef _WIN32
    
	Sleep((DWORD)ms);
#else
    
	usleep((useconds_t)(ms * 1000.0));
#endif

	return newNumVal(1);
}

ShellValue native_list(int argc, ShellValue *args) {
	if (argc < 1 || args[0].type != VAL_DICT) { 
		return newNumVal(-1);
	}

    
	InstanceObj *inst = (InstanceObj*)((size_t)args[0].as.comodin - sizeof(GCObj));
	EvalCtx *inst_ctx = inst->ctx;

    
	ShellValue arr_instance = native_array_constructor(0, NULL);
	InstanceObj *arr_inst = (InstanceObj*)((size_t)arr_instance.as.comodin - sizeof(GCObj));
	Array *arr = (getShellVarEntrySilent(arr_inst->ctx, "data"))->val.as.arr;

    
	for (size_t i = 0; i < inst_ctx->var_cap; i++) {
		Var *v = &inst_ctx->var_table[i];
		if (v->is_set && v->name != NULL) {
            
			if (arr->size >= arr->capacity) {
				growArray(arr);
			}
			arr->items[arr->size++] = ref_add(newStrVal(v->name));
		}
	}

	return arr_instance;
}

ShellValue native_writeB(int argc, ShellValue *args) {
    if (argc < 2 || args[0].type != VAL_STRING || args[1].type != VAL_OBJ) {
        return newNumVal(0);
    }
    
    FILE *f = fopen(args[0].as.str, "wb");
    if (!f) return newNumVal(0);
    
    fwrite(args[1].as.obj->info, sizeof(unsigned char), args[1].as.obj->capacity, f);
    fclose(f);
    return newNumVal(1); // Éxito, YUPIIII
}


ShellValue native_readB(int argc, ShellValue *args) {
    if (argc < 1 || args[0].type != VAL_STRING) {
        return newNumVal(-1);
    }
    
    FILE *f = fopen(args[0].as.str, "rb");
    if (!f) return newNumVal(-1);

    // a ver, en plan solo asignar lo q necesito
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
 
    ShellValue val = newObjVal(len);
    fread(val.as.obj->info, 1, len, f); 
    fclose(f);

    return val;
}

ShellValue native_slice(int argc, ShellValue *args) {
	if (argc < 3) return newNumVal(-1);
	size_t size = (size_t)((int)args[1].as.num + (int)args[2].as.num);
	char *buffer = malloc(size+1);
	// con eso pillamos un buffer q va a poder pillar todo el tamaño creo
	// ahora copiamos con memcpy
	memcpy(buffer, &args[0].as.str[(int)args[1].as.num], size);
	buffer[size] = '\0';
	ShellValue val = newStrVal(buffer);
	free(buffer);
	return val;
}

ShellValue native_rename(int argc, ShellValue *args) {
	if (argc < 2) return newNumVal(-1);
	return newNumVal(rename(args[0].as.str, args[1].as.str));
}
ShellValue native_remove(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newNumVal(remove(args[0].as.str));
}

ShellValue native_ls(int argc, ShellValue *args) {
    const char *path = ".";
    if (argc >= 1 && args[0].type == VAL_STRING && args[0].as.str != NULL) {
        path = args[0].as.str;
    }

    DIR *dir = opendir(path);
    if (!dir) {
        return newNumVal(-1); // jejejejejjeje, no se como va esto
			      // solo le pedi ayuda a internet
    }

    
    ShellValue arr_instance = native_array_constructor(0, NULL);
    
    // creo q estoy intentando sacar el array interno de la clase
    InstanceObj *inst = (InstanceObj*)((size_t)arr_instance.as.comodin - sizeof(GCObj));
    EvalCtx *inst_ctx = inst->ctx;
    ShellValue data_val = (getShellVarEntrySilent(inst_ctx, "data"))->val;
    Array *arr = data_val.as.arr;

    // AHORA, o al menos segun internet toca leer el directorio para saber las cosas, idk
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (arr->size >= arr->capacity) {
            growArray(arr);
        }
        ShellValue item_str = newStrVal(entry->d_name);
        arr->items[arr->size++] = ref_add(item_str);
    }

    closedir(dir);

    // devolvemos un array q espero q no explote
    return arr_instance;
}

ShellValue native_cwd(int argc, ShellValue *args) {
    
    char buffer[1024];
    if (getcwd(buffer, sizeof(buffer)) != NULL) {
        return newStrVal(buffer);
    }
    return newStrVal("");
}

ShellValue native_chdir(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newNumVal(chdir(args[0].as.str));
}

ShellValue native_eval(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(0);
	char *str = args[0].as.str;

	EvalCtx *current = newShellCtx();
	lexer_init(str);
	Token *t_buff = lexe(NULL);
	parser_init(t_buff);
	ASTNode *tree=parse();

	eval(tree, current);
	track_pointer(tree, PTR_AST);
	track_pointer(t_buff, PTR_TOKENS);
	track_pointer(t_buff, PTR_RAW);

	ShellValue val = newInstanceVal(current);
	return val;
}

ShellValue native_getenv(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	char *ptr = getenv(args[0].as.str);
	ShellValue val = newStrVal(ptr);
	return val;
}

ShellValue native_max(int argc, ShellValue *args) {
	if (argc < 2) return newNumVal(-1);
	return (args[0].as.num > args[1].as.num) ? args[0] : args[1];
}
ShellValue native_min(int argc, ShellValue *args) {
	if (argc < 2) return newNumVal(-1);
	return (args[0].as.num < args[1].as.num) ? args[0] : args[1];
}

ShellValue native_newb(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newObjVal((size_t)args[0].as.num);
}

ShellValue native_setb(int argc, ShellValue *args) {
	if (argc < 3) return newNumVal(-1);
	Object *obj = args[0].as.obj;
	size_t pos = (size_t)args[1].as.num;
	uint8_t new_val = (uint8_t)args[2].as.num;
	obj->info[pos] = new_val; // yay
	return newNumVal(0);
}

ShellValue native_getb(int argc, ShellValue *args) {
	if (argc < 2) return newNumVal(-1);
	Object *obj = args[0].as.obj;
	size_t pos = (size_t)args[1].as.num;
	// yippppppieeeee, idk
	return newNumVal((double)obj->info[pos]);
}
/*
 *
 * This functions will come soon, yk, i think they would be useful
 * idk
 *
 *
ShellValue native_text2b(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	ShellValue val = newObjVal(strlen(args[0].as.str));

}

ShellValue native_b2text(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	if (args[0].type!=VAL_OBJ) return newNumVal(-1);
	Object *obj = 
	return newStrVal();
}
*/
ShellValue native_chr(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	char buffi[2];
	buffi[0] = (char)args[0].as.num;
	buffi[1] = '\0';
	return newStrVal(buffi);
}

ShellValue native_ord(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	char ch = args[0].as.str[0]; // pillamos el primer caractér
	return newNumVal((double)ch);
}

ShellValue native_float(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return newNumVal(atof(args[0].as.str));
}

ShellValue native_str(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	char buffer[512];
	snprintf(buffer, sizeof(buffer), "%lf", args[0].as.num);
	buffer[511] = '\0';
	return newStrVal(buffer);
}

ShellValue native_args(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(-1);
	return getShellArg(get_global(), (size_t)args[0].as.num);
}
	

// ahora algo del tiempo, para los benchmarks
#include <sys/time.h>
ShellValue native_clock(int argc, ShellValue *args) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    double seconds = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
    return newNumVal(seconds);
}

typedef void (*RegisterLibFunc)(EvalCtx *ctx);

ShellValue native_system(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(0);
	char *str = args[0].as.str;
	system(str);
	return newNumVal(1);
}

#ifdef _WIN32
#include <windows.h>
typedef void (*RegisterLibFunc)(EvalCtx *ctx);

int load_plugins(const char *file, EvalCtx *ctx) {
 
    HMODULE handle = LoadLibraryA(file);
    if (!handle) {
        printf("Err -> Error while Loading .dll\n");
        return 0;
    }

    RegisterLibFunc register_lib = (RegisterLibFunc)GetProcAddress(handle, "register_lib");
    if (!register_lib) {
        printf("Err -> Error, 'register_lib' not found\n");
        FreeLibrary(handle);
        return 0;
    }

    register_lib(ctx);
    return 0;
}
#else
#include <dlfcn.h>

int load_plugins(const char *file, EvalCtx *ctx) {
    void *handle = dlopen(file, RTLD_NOW);
    if (!handle) {
        printf("Err -> Error while Loading .so\n");
        return 0;
    }
    dlerror();

    RegisterLibFunc register_lib = (RegisterLibFunc)dlsym(handle, "register_lib");
    char *error = dlerror();
    if (error != NULL) {
        printf("Err -> Error, 'register_lib' not found\n");
        dlclose(handle);
        return 0;
    }

    register_lib(ctx);
    return 0;
}
#endif

ShellValue native_include(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(0);
	char *str = args[0].as.str;
	load_plugins(str, get_global());
	return newNumVal(1);
}



int how_many=0;
int current_cap = MAX_NATIVE_FUNCS;

CFunc *natives;

ShellValue native_import(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(0);
	char *str = args[0].as.str;
	FILE *f = fopen(str, "rb");
	fseek(f, 0, SEEK_END);
	size_t size = ftell(f);
	fseek(f, 0, SEEK_SET);
	char *buffer = kmalloc(size+1);
	size_t _read = fread(buffer, 1, size, f);
	buffer[size] = '\0';
	size_t offset = 0;

	if (_read >= 3 && (buffer[0]==0xEF && buffer[1]==0xBB && buffer[2]==0xBF)) {
		offset = 3;
	}

	char *real_buff = (char*)((size_t)buffer + offset);

	EvalCtx *current = newShellCtx();
	lexer_init(real_buff);
	Token *t_buff = lexe(NULL);
	parser_init(t_buff);
	ASTNode *tree=parse();

	eval(tree, current);
	track_pointer(tree, PTR_AST);
	track_pointer(t_buff, PTR_TOKENS);
	track_pointer(t_buff, PTR_RAW);

	ShellValue val = newInstanceVal(current);
	free(buffer);
	return val;
}

void cleanAll() {
	free_tracked_memory();
}

ShellValue native_write(int argc, ShellValue *args) {
    if (argc < 2 || args[0].type != VAL_STRING || args[1].type != VAL_STRING) {
        return newNumVal(0);
    }
    
    FILE *f = fopen(args[0].as.str, "w");
    if (!f) return newNumVal(0);
    
    fputs(args[1].as.str, f);
    fclose(f);
    return newNumVal(1); // Éxito, YUPIIII
}

// read("algo.txt")
ShellValue native_read(int argc, ShellValue *args) {
    if (argc < 1 || args[0].type != VAL_STRING) {
        return newStrVal("");
    }
    
    FILE *f = fopen(args[0].as.str, "r");
    if (!f) return newStrVal("");

    // a ver, en plan solo asignar lo q necesito
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);

    char *buf = kmalloc(len + 1);
    if (!buf) {
        fclose(f);
        return newStrVal("");
    }
    
    fread(buf, 1, len, f);
    buf[len] = '\0';
    fclose(f);

    ShellValue val = newStrVal(buf);
    kfree(buf);
    return val;
}

ShellValue native_input(int argc, ShellValue *args) {
    char buffer[256];
    if (argc > 0 && args[0].type == VAL_STRING) {
        kprintf("%s", args[0].as.str); 
    }
    
    
    if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        }
        return newStrVal(buffer);
    }
    return newStrVal("NULL");
}

ShellValue native_array_push(int argc, ShellValue *args) {
    
    if (argc < 2) return newNumVal(0);
    
    InstanceObj *inst = (InstanceObj*)((size_t)args[0].as.comodin - sizeof(GCObj));


    EvalCtx *inst_ctx = inst->ctx;

    ShellValue val = (getShellVarEntrySilent(inst_ctx, "data"))->val;
    Array *arr = val.as.arr;
    if (arr->size >= arr->capacity) growArray(arr);
    arr->items[arr->size++]=ref_add(args[1]);
    return newNumVal(0);
}

ShellValue native_array_pop(int argc, ShellValue *args) {
    
    if (argc < 1) return newNumVal(0);
    InstanceObj *inst = (InstanceObj*)((size_t)args[0].as.comodin - sizeof(GCObj));


    EvalCtx *inst_ctx = inst->ctx;

    ShellValue val = (getShellVarEntrySilent(inst_ctx, "data"))->val; 
    Array *arr = val.as.arr;
    arr->size--;
    ref_del(arr->items[arr->size]);
    return newNumVal(0);
}

ShellValue native_array_len(int argc, ShellValue *args) { 
    if (argc < 1) return newNumVal(0);
    InstanceObj *inst = (InstanceObj*)((size_t)args[0].as.comodin - sizeof(GCObj));


    EvalCtx *inst_ctx = inst->ctx;

    ShellValue val = (getShellVarEntrySilent(inst_ctx, "data"))->val; 
    Array *arr = val.as.arr;
    return newNumVal(arr->size);
}

static CFunc prefab_fn[3] = {
    { .func = native_array_push },
    { .func = native_array_pop },
    { .func = native_array_len }
};

ShellValue native_array_constructor(int argc, ShellValue *args) {
    
    EvalCtx *instance_ctx = newShellCtx();
    
    ShellValue arr_val = newArrayVal(); 
    
    defShellVarEntry(instance_ctx, "data", arr_val);

    
    rregister_cfunc(instance_ctx, "push", &prefab_fn[0]);
    rregister_cfunc(instance_ctx, "pop", &prefab_fn[1]);
    rregister_cfunc(instance_ctx, "len", &prefab_fn[2]);


    return newInstanceVal(instance_ctx);
}

ShellValue len(int argc, ShellValue *args) {
	if (argc < 1) return newNumVal(0);
	if (args[0].type==VAL_STRING) {
		return newNumVal(strlen(args[0].as.str));
	} else if (args[0].type==VAL_OBJ) {
		return newNumVal((double)args[0].as.obj->capacity);
	}
	return newNumVal(0);
}

ShellValue zindex(int argc, ShellValue *args) {
		if (argc < 2) return newNumVal(0);
		if (args[0].type==VAL_STRING) {
				char str[2];
				str[1] = '\0';
				str[0] = args[0].as.str[(int)args[1].as.num];
				return newStrVal(str);
		} else if (args[0].type==VAL_ARRAY) {
			return args[0].as.arr->items[(int)args[1].as.num];
		}
		return newNumVal(0);
}

void register_cfunc(EvalCtx *ctx, char *name, NativeFunc func) {
	ShellValue val;
	val.type = VAL_CFUNC;
	if (how_many >= current_cap) {
		current_cap *= 2;
		natives = realloc(natives, current_cap*sizeof(CFunc));
	}
	CFunc *var=&natives[how_many++];
	var->func = func;
	val.as.c_func = var;
	defShellVarEntry(ctx, name, val);
}

void rregister_cfunc(EvalCtx *ctx, char *name, CFunc *func) {
	ShellValue val;
	val.type = VAL_CFUNC;
	val.as.c_func = func;
	defShellVarEntry(ctx, name, val);
}

void register_class(EvalCtx *ctx, char *name, EvalCtx *class) {	
	defShellVarEntry(ctx, name, newInstanceVal(class));
}

void initFuncStorage() {
	natives = malloc(current_cap*sizeof(CFunc));
}

void cleanFuncStorage() {
	free(natives);
}

void register_globals(EvalCtx *ctx) {
	register_cfunc(ctx, "len", len);
	register_cfunc(ctx, "index", zindex);
	register_cfunc(ctx, "Array", native_array_constructor);
	register_cfunc(ctx, "input", native_input);
	register_cfunc(ctx, "read", native_read);
	register_cfunc(ctx, "write", native_write);
	register_cfunc(ctx, "import", native_import);
	register_cfunc(ctx, "include", native_include);
	register_cfunc(ctx, "system", native_system);
	register_cfunc(ctx, "clock", native_clock);
	register_cfunc(ctx, "arg", native_args);
	register_cfunc(ctx, "float", native_float);
	register_cfunc(ctx, "str", native_str);
	register_cfunc(ctx, "chr", native_chr);
	register_cfunc(ctx, "ord", native_ord);
	register_cfunc(ctx, "newb", native_newb);
	register_cfunc(ctx, "setb", native_setb);
	register_cfunc(ctx, "getb", native_getb);
	register_cfunc(ctx, "max", native_max);
	register_cfunc(ctx, "min", native_min);
	register_cfunc(ctx, "getenv", native_getenv);
	register_cfunc(ctx, "eval", native_eval);
	register_cfunc(ctx, "chdir", native_chdir);
	register_cfunc(ctx, "cwd", native_cwd);
	register_cfunc(ctx, "listdir", native_ls);
	register_cfunc(ctx, "rename", native_rename);
	register_cfunc(ctx, "remove", native_remove);
	register_cfunc(ctx, "writeB", native_writeB);
	register_cfunc(ctx, "readB", native_readB);
	register_cfunc(ctx, "list", native_list);
	register_cfunc(ctx, "sleep", native_sleep);
	register_cfunc(ctx, "slice", native_slice);
	register_cfunc(ctx, "exists", native_exists);
	register_cfunc(ctx, "sqrt", native_sqrt);
	register_cfunc(ctx, "abs", native_abs);
	register_cfunc(ctx, "pow", native_pow);
	register_cfunc(ctx, "ln", native_ln);
}
